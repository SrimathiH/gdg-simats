import React from 'react';
import './HeroSection.css';
import BackgroundImage from './assets/Add a subheading.png';



const HeroSection = () => {
  return (
    <section className="hero-section">
      <div className="card">
        <div className="hero-text">
          <h1>
            Google <span className="highlight">Developers</span> Group – SIMATS
          </h1>
          <p>
            Organizers of Google Developer Groups are passionate leaders in their community who are dedicated to helping others learn and connect. GDG organizers plan and host meetup events on a wide range of technical topics typically on a monthly basis in a location near them.
          </p>
          <div className="hero-buttons">
            <button className="join-now-btn">
              <i className="fas fa-rocket"></i> Join Now
            </button>
            <button className="events-btn">Events</button>
          </div>
        </div>
        <div className="hero-image">
          <img src={BackgroundImage} alt="Phone Mockup" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
