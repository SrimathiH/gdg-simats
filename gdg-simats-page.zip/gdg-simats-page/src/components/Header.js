import React from 'react';
import './Header.css';
import logo from './assets/image.png'; // Update this with the actual path to your logo image

const Header = () => {
  return (
    <header className="header">
      <div className="header-logo">
        <img src={logo} alt="GDG on Campus – SIMATS" className="logo-image" />
      </div>
      <button className="join-now-btn">Join Now</button>
    </header>
  );
};

export default Header;
